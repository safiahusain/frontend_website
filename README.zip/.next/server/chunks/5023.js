"use strict";
exports.id = 5023;
exports.ids = [5023];
exports.modules = {

/***/ 5023:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "J$": () => (/* binding */ fetchBlogs),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export Blogs */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

//intialState
const initialState = {
    Blogs: null,
    status: null
};
//fetch data from api
const fetchBlogs = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("BLOG/fetchBlogs", async ()=>{
    try {
        const res = await fetch(`${"https://conquerortrading.com/"}api/blog`, {
            method: "GET",
            headers: {
                "Content-Type": "application/json"
            }
        });
        const data = await res.json();
        return data;
    } catch (err) {
        console.log(err);
        return false;
    }
});
//create action and reducer
const Blogs = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: " BLOG",
    initialState,
    extraReducers: {
        [fetchBlogs.pending]: (state, action)=>{
            state.status = "loading";
        },
        [fetchBlogs.fulfilled]: (state, { payload  })=>{
            state.Blogs = payload;
            state.status = "success";
        },
        [fetchBlogs.rejected]: (state, action)=>{
            state.status = "failed";
        }
    }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Blogs.reducer);


/***/ })

};
;