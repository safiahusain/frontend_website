"use strict";
exports.id = 5023;
exports.ids = [5023];
exports.modules = {

/***/ 5023:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HD": () => (/* binding */ GetSecurityAndPayments),
/* harmony export */   "J$": () => (/* binding */ fetchBlogs),
/* harmony export */   "PX": () => (/* binding */ GetDeliveryAndReturns),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export Blogs */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

//intialState
const initialState = {
    Blogs: null,
    status: null,
    deliverReturns: null,
    securityPayments: null
};
//fetch data from api
const fetchBlogs = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("BLOG/fetchBlogs", async ()=>{
    try {
        const res = await fetch(`${"https://admin.bynunaonlinestore.com/"}api/blog`, {
            method: "GET",
            headers: {
                "Content-Type": "application/json"
            }
        });
        const data = await res.json();
        return data;
    } catch (err) {
        console.log(err);
        return false;
    }
});
const GetDeliveryAndReturns = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("BLOG/GetDeliveryAndReturns", async ()=>{
    try {
        const res = await fetch(`${"https://admin.bynunaonlinestore.com/"}api/delivery-and-returns`, {
            method: "GET",
            headers: {
                "Content-Type": "application/json"
            }
        });
        const data = await res.json();
        return data.delivery_returns;
    } catch (err) {
        console.log(err);
    }
});
const GetSecurityAndPayments = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("BLOG/GetSecurityAndPayments", async ()=>{
    try {
        const res = await fetch(`${"https://admin.bynunaonlinestore.com/"}api/security-and-payments`, {
            method: "GET",
            headers: {
                "Content-Type": "application/json"
            }
        });
        const data = await res.json();
        return data.security_payments;
    } catch (err) {
        console.log(err);
    }
});
//create action and reducer
const Blogs = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: " BLOG",
    initialState,
    extraReducers: (builder)=>{
        //Get MainPage Blogs/////////
        builder.addCase(fetchBlogs.pending, (state)=>{
            state.status = "loading";
        });
        builder.addCase(fetchBlogs.fulfilled, (state, action)=>{
            state.Blogs = action.payload;
            state.status = "success";
        });
        builder.addCase(fetchBlogs.rejected, (state, action)=>{
            state.status = "failed";
        });
        //Get Deliver and Returns data/////////
        builder.addCase(GetDeliveryAndReturns.pending, (state)=>{
            state.status = "loading";
        });
        builder.addCase(GetDeliveryAndReturns.fulfilled, (state, action)=>{
            state.deliverReturns = action.payload;
            state.status = "success";
        });
        builder.addCase(GetDeliveryAndReturns.rejected, (state, action)=>{
            state.status = "failed";
        });
        //Get Security and Payments /////////
        builder.addCase(GetSecurityAndPayments.pending, (state)=>{
            state.status = "loading";
        });
        builder.addCase(GetSecurityAndPayments.fulfilled, (state, action)=>{
            state.securityPayments = action.payload;
            state.status = "success";
        });
        builder.addCase(GetSecurityAndPayments.rejected, (state, action)=>{
            state.status = "failed";
        });
    }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Blogs.reducer);


/***/ })

};
;